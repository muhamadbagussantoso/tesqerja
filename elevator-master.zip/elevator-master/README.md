Elevator Simulation Problem  
  
Edit only the function definition of Elevator.prototype.decide() in myelevator.js.  
That function is called when elevator needs to decide which floor it needs to go to.  
Try to:  
1. minimize total_people_wait_time_in_elevator  
2. minimize total_people_wait_time_out_elevator  
3. minimize total_elevator_traveled_distance  
4. maximize total_delivered_people  
